package ar.com.eduit.curso.java.web.colegio.enums;

public enum Turno {
    MAÑANA,
    TARDE,
    NOCHE
}
