use colegio;
drop table if exists control_auditoria;
drop table if exists cursos_eliminados;
drop table if exists alumnos_eliminados;

CREATE TABLE control_auditoria(
    id int AUTO_INCREMENT PRIMARY KEY,
    tabla VARCHAR(50) NOT NULL,
    evento ENUM('INSERT','DELETE','UPDATE') NOT NULL,
    id_registro INT,
    fecha date,
    hora time,
    usuario VARCHAR(50)
);
CREATE TABLE cursos_eliminados(
    id int auto_increment primary key,
    titulo varchar(50) not null, 
    profesor varchar(50) not null,
    dia enum('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES') not null,
    turno enum('MAÑANA','TARDE','NOCHE') not null,
    fecha date,
    hora time
);
CREATE TABLE alumnos_eliminados(
    id int auto_increment primary key,
    nombre varchar(50) not null,
    apellido varchar(50) not null, 
    edad int not null,
    id_curso int not null,
    fecha date,
    hora time
);

DROP TRIGGER IF EXISTS TR_cursos_insert;
CREATE TRIGGER TR_cursos_insert
AFTER INSERT ON cursos FOR EACH ROW
BEGIN
    INSERT INTO control_auditoria
    (tabla,evento,id_registro,fecha,hora,usuario)
    VALUES
    ('cursos','INSERT',NEW.id,CURDATE(),CURTIME(),USER());
END;
INSERT INTO cursos (titulo, profesor, dia, turno)
VALUES ('Matemática', 'Juan Pérez', 'LUNES', 'MAÑANA');
-- Verificar que el curso fue insertado
SELECT * FROM cursos;
-- Verificar que el evento fue registrado en control_auditoria
SELECT * FROM control_auditoria;

DROP TRIGGER IF EXISTS TR_cursos_update;
CREATE TRIGGER TR_cursos_update
AFTER UPDATE ON cursos FOR EACH ROW
BEGIN
    INSERT INTO control_auditoria
    (tabla,evento,id_registro,fecha,hora,usuario)
    VALUES
    ('cursos','UPDATE',NEW.id,CURDATE(),CURTIME(),USER());
END;
UPDATE cursos
SET titulo = 'Matemática Avanzadas', profesor = 'María López'
WHERE id = 1;
-- Verificar los datos actualizados en la tabla cursos
SELECT * FROM cursos WHERE id = 1;
-- Verificar que el evento fue registrado en control_auditoria
SELECT * FROM control_auditoria WHERE evento = 'UPDATE';
SELECT * FROM control_auditoria;
DROP TRIGGER IF EXISTS TR_cursos_delete;
CREATE TRIGGER TR_cursos_delete
AFTER DELETE ON cursos FOR EACH ROW
BEGIN
    INSERT INTO control_auditoria
    (tabla,evento,id_registro,fecha,hora,usuario)
    VALUES
    ('cursos','DELETE',OLD.id,CURDATE(),CURTIME(),USER());

    INSERT INTO cursos_eliminados
    (titulo,profesor,dia,turno,fecha,hora)
    VALUES
    (OLD.titulo,OLD.profesor,OLD.dia,OLD.turno,CURDATE(),CURTIME());    
END;

INSERT INTO cursos (titulo, profesor, dia, turno)
VALUES ('Historia', 'Ana Gómez', 'MARTES', 'TARDE');

INSERT INTO cursos (titulo, profesor, dia, turno)
VALUES ('Física', 'Carlos Méndez', 'MIERCOLES', 'NOCHE');
DELETE FROM cursos
WHERE id = 2; -- Cambia el ID si deseas eliminar otro curso.

SELECT * FROM cursos;
-- Verificar que el curso eliminado fue registrado en la tabla cursos_eliminados
SELECT * FROM cursos_eliminados;
-- Verificar que el evento fue registrado en control_auditoria
SELECT * FROM control_auditoria WHERE evento = 'DELETE';


DROP TRIGGER IF EXISTS TR_alumnos_insert;
CREATE TRIGGER TR_alumnos_insert
AFTER INSERT ON alumnos FOR EACH ROW
BEGIN
    INSERT INTO control_auditoria
    (tabla,evento,id_registro,fecha,hora,usuario)
    VALUES
    ('alumnos','INSERT',NEW.id,CURDATE(),CURTIME(),USER());
END;
INSERT INTO alumnos (nombre, apellido, edad, id_curso)
VALUES ('Lucía', 'Martínez', 25, 1);
-- Verificar que el alumno fue insertado
SELECT * FROM alumnos;
-- Verificar que el evento fue registrado en control_auditoria
SELECT * FROM control_auditoria WHERE evento = 'INSERT';

DROP TRIGGER IF EXISTS TR_alumnos_update;
CREATE TRIGGER TR_alumnos_update
AFTER UPDATE ON alumnos FOR EACH ROW
BEGIN
    INSERT INTO control_auditoria
    (tabla,evento,id_registro,fecha,hora,usuario)
    VALUES
    ('alumnos','UPDATE',NEW.id,CURDATE(),CURTIME(),USER());
END;
UPDATE alumnos
SET nombre = 'Lucía Gabriela', apellido = 'Martínez López', edad = 26
WHERE id = 1;
-- Verificar los datos actualizados en la tabla alumnos
SELECT * FROM alumnos WHERE id = 1;

-- Verificar que el evento fue registrado en control_auditoria
SELECT * FROM control_auditoria WHERE evento = 'UPDATE';


DROP TRIGGER IF EXISTS TR_alumnos_delete;
CREATE TRIGGER TR_alumnos_delete
AFTER DELETE ON alumnos FOR EACH ROW
BEGIN
    INSERT INTO control_auditoria
    (tabla,evento,id_registro,fecha,hora,usuario)
    VALUES
    ('alumnos','DELETE',OLD.id,CURDATE(),CURTIME(),USER());

    INSERT INTO alumnos_eliminados
    (nombre,apellido,edad,id_curso,fecha,hora)
    VALUES
    (OLD.nombre,OLD.apellido,OLD.edad,OLD.id_curso,CURDATE(),CURTIME());
END;

INSERT INTO alumnos (nombre, apellido, edad, id_curso)
VALUES ('Juan', 'Pérez', 30, 1);
INSERT INTO alumnos (nombre, apellido, edad, id_curso)
VALUES ('Fabrizio', 'López', 30, 1);
SELECT * FROM alumnos;
DELETE FROM alumnos
WHERE id = 1; -- Cambia el ID al del alumno que desees eliminar
-- Verificar que el alumno fue eliminado de la tabla alumnos
SELECT * FROM alumnos;

-- Verificar que el alumno eliminado está en alumnos_eliminados
SELECT * FROM alumnos_eliminados;
SELECT * FROM cursos_eliminados;
-- Verificar que el evento fue registrado en control_auditoria
SELECT * FROM control_auditoria WHERE evento = 'DELETE';
